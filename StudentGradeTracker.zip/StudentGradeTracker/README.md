# Student Grade Tracker (Eclipse project)

Console-based Java app using ArrayLists: add/update/remove students, add scores,
average / highest / lowest (per student and class-wide), and a summary report table.

## Import into Eclipse
File > Import... > General > Existing Projects into Workspace > select this folder (or the .zip) > Finish

## Run
Right-click src/StudentGradeTracker.java > Run As > Java Application.
Type your input in Eclipse's Console tab (click inside it first).

Requires JDK 11 or newer.
