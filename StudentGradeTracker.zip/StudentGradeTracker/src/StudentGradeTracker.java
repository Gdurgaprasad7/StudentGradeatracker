import java.util.ArrayList;
import java.util.Scanner;

/**
 * Student Grade Tracker (console-based)
 * - Stores students in an ArrayList; each student's scores are stored in an ArrayList too
 * - Calculates average, highest and lowest scores (per student and class-wide)
 * - Displays a summary report of all students
 */
public class StudentGradeTracker {

    // ---------- Student model ----------
    static class Student {
        private final int id;
        private String name;
        private final ArrayList<Double> scores = new ArrayList<>();

        Student(int id, String name) {
            this.id = id;
            this.name = name;
        }

        int getId() { return id; }
        String getName() { return name; }
        void setName(String name) { this.name = name; }
        ArrayList<Double> getScores() { return scores; }
        void addScore(double s) { scores.add(s); }
        boolean hasScores() { return !scores.isEmpty(); }

        double getAverage() {
            if (scores.isEmpty()) return 0;
            double sum = 0;
            for (double s : scores) sum += s;
            return sum / scores.size();
        }

        double getHighest() {
            double max = Double.NEGATIVE_INFINITY;
            for (double s : scores) if (s > max) max = s;
            return scores.isEmpty() ? 0 : max;
        }

        double getLowest() {
            double min = Double.POSITIVE_INFINITY;
            for (double s : scores) if (s < min) min = s;
            return scores.isEmpty() ? 0 : min;
        }

        String getLetterGrade() {
            if (scores.isEmpty()) return "-";
            double avg = getAverage();
            if (avg >= 90) return "A";
            if (avg >= 80) return "B";
            if (avg >= 70) return "C";
            if (avg >= 60) return "D";
            return "F";
        }
    }

    // ---------- State ----------
    private static final ArrayList<Student> students = new ArrayList<>();
    private static final Scanner in = new Scanner(System.in);
    private static int nextId = 1;

    // ---------- Main menu ----------
    public static void main(String[] args) {
        System.out.println("=====================================");
        System.out.println("       STUDENT GRADE TRACKER");
        System.out.println("=====================================");

        boolean running = true;
        while (running) {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Add student");
            System.out.println("2. Add score to a student");
            System.out.println("3. Update student name");
            System.out.println("4. Remove student");
            System.out.println("5. View one student");
            System.out.println("6. Class statistics (average / highest / lowest)");
            System.out.println("7. Summary report");
            System.out.println("0. Exit");

            int choice = readInt("Choose an option: ", 0, 7);
            switch (choice) {
                case 1: addStudent(); break;
                case 2: addScore(); break;
                case 3: updateName(); break;
                case 4: removeStudent(); break;
                case 5: viewStudent(); break;
                case 6: classStatistics(); break;
                case 7: summaryReport(); break;
                case 0: running = false; break;
            }
        }
        System.out.println("Goodbye!");
    }

    // ---------- Operations ----------
    private static void addStudent() {
        String name = readNonEmpty("Enter student name: ");
        Student s = new Student(nextId++, name);
        students.add(s);
        System.out.println("Added " + name + " (ID " + s.getId() + ").");

        String more = readNonEmpty("Enter scores now? (y/n): ");
        if (more.equalsIgnoreCase("y")) {
            int n = readInt("How many scores? ", 1, 100);
            for (int i = 1; i <= n; i++) {
                s.addScore(readDouble("  Score " + i + " (0-100): ", 0, 100));
            }
            System.out.println("Scores saved.");
        }
    }

    private static void addScore() {
        Student s = pickStudent();
        if (s == null) return;
        s.addScore(readDouble("Enter score (0-100): ", 0, 100));
        System.out.println("Score added to " + s.getName() + ".");
    }

    private static void updateName() {
        Student s = pickStudent();
        if (s == null) return;
        s.setName(readNonEmpty("New name: "));
        System.out.println("Name updated.");
    }

    private static void removeStudent() {
        Student s = pickStudent();
        if (s == null) return;
        students.remove(s);
        System.out.println("Removed " + s.getName() + ".");
    }

    private static void viewStudent() {
        Student s = pickStudent();
        if (s == null) return;
        System.out.println("\nStudent : " + s.getName() + " (ID " + s.getId() + ")");
        if (!s.hasScores()) {
            System.out.println("No scores recorded yet.");
            return;
        }
        System.out.println("Scores  : " + s.getScores());
        System.out.printf("Average : %.2f%n", s.getAverage());
        System.out.printf("Highest : %.2f%n", s.getHighest());
        System.out.printf("Lowest  : %.2f%n", s.getLowest());
        System.out.println("Grade   : " + s.getLetterGrade());
    }

    private static void classStatistics() {
        ArrayList<Double> all = allScores();
        if (all.isEmpty()) {
            System.out.println("No scores available yet.");
            return;
        }
        double sum = 0, max = all.get(0), min = all.get(0);
        for (double d : all) {
            sum += d;
            if (d > max) max = d;
            if (d < min) min = d;
        }
        System.out.println("\n--- CLASS STATISTICS ---");
        System.out.println("Total scores : " + all.size());
        System.out.printf("Average      : %.2f%n", sum / all.size());
        System.out.printf("Highest      : %.2f (%s)%n", max, ownerOf(max, true));
        System.out.printf("Lowest       : %.2f (%s)%n", min, ownerOf(min, false));
    }

    private static void summaryReport() {
        if (students.isEmpty()) {
            System.out.println("No students to report.");
            return;
        }
        String line = "+------+----------------------+--------+---------+---------+-------+";
        System.out.println("\n" + line);
        System.out.printf("| %-4s | %-20s | %-6s | %-7s | %-7s | %-5s |%n",
                "ID", "Name", "Scores", "Average", "Highest", "Grade");
        System.out.println(line);

        for (Student s : students) {
            String name = s.getName().length() > 20 ? s.getName().substring(0, 17) + "..." : s.getName();
            if (s.hasScores()) {
                System.out.printf("| %-4d | %-20s | %-6d | %-7.2f | %-7.2f | %-5s |%n",
                        s.getId(), name, s.getScores().size(), s.getAverage(), s.getHighest(), s.getLetterGrade());
            } else {
                System.out.printf("| %-4d | %-20s | %-6d | %-7s | %-7s | %-5s |%n",
                        s.getId(), name, 0, "N/A", "N/A", "-");
            }
        }
        System.out.println(line);

        // Class-wide footer
        ArrayList<Double> all = allScores();
        if (!all.isEmpty()) {
            double sum = 0, max = all.get(0), min = all.get(0);
            for (double d : all) {
                sum += d;
                if (d > max) max = d;
                if (d < min) min = d;
            }
            System.out.printf("Students: %d | Class average: %.2f | Highest score: %.2f | Lowest score: %.2f%n",
                    students.size(), sum / all.size(), max, min);

            Student top = null, bottom = null;
            for (Student s : students) {
                if (!s.hasScores()) continue;
                if (top == null || s.getAverage() > top.getAverage()) top = s;
                if (bottom == null || s.getAverage() < bottom.getAverage()) bottom = s;
            }
            System.out.printf("Top performer: %s (%.2f) | Needs most support: %s (%.2f)%n",
                    top.getName(), top.getAverage(), bottom.getName(), bottom.getAverage());
        }
    }

    // ---------- Helpers ----------
    private static ArrayList<Double> allScores() {
        ArrayList<Double> all = new ArrayList<>();
        for (Student s : students) all.addAll(s.getScores());
        return all;
    }

    /** Finds the name of the student who owns the highest/lowest score. */
    private static String ownerOf(double value, boolean highest) {
        for (Student s : students) {
            if (s.hasScores() && (highest ? s.getHighest() : s.getLowest()) == value) return s.getName();
        }
        return "?";
    }

    private static Student pickStudent() {
        if (students.isEmpty()) {
            System.out.println("No students yet. Add one first.");
            return null;
        }
        System.out.println("Students:");
        for (Student s : students) System.out.println("  " + s.getId() + " - " + s.getName());
        int id = readInt("Enter student ID: ", 1, Integer.MAX_VALUE);
        for (Student s : students) if (s.getId() == id) return s;
        System.out.println("No student with ID " + id + ".");
        return null;
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = in.hasNextLine() ? in.nextLine().trim() : "";
            if (!s.isEmpty()) return s;
            if (!in.hasNextLine()) { System.out.println("\nInput ended."); System.exit(0); }
            System.out.println("Input cannot be empty.");
        }
    }

    private static int readInt(String prompt, int min, int max) {
        while (true) {
            String s = readNonEmpty(prompt);
            try {
                int v = Integer.parseInt(s);
                if (v >= min && v <= max) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println("Please enter a whole number between " + min + " and " + (max == Integer.MAX_VALUE ? "any" : max) + ".");
        }
    }

    private static double readDouble(String prompt, double min, double max) {
        while (true) {
            String s = readNonEmpty(prompt);
            try {
                double v = Double.parseDouble(s);
                if (v >= min && v <= max) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println("Please enter a number between " + min + " and " + max + ".");
        }
    }
}
